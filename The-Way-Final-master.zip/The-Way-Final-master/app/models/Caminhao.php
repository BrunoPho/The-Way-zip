<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 13/07/18
 * Time: 13:29
 */

class Caminhao
{
    public $cod_caminhao;
    public $ano_modelo;
    public $ano_fabricacao;
    public $capacidade;
    public $cod_modelo;
    public $cod_tipo;

    public function __construct(){ // Não é obrigado a passar ano_modelo e ano_fabricacao

    }

}