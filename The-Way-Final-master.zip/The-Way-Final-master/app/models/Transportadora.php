<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 13/08/2018
 * Time: 13:46
 */

class Transportadora {

    public $cod_transportadora;
    public $nome;
    public $email;
    public $telefone;
    public $senha;
    public $razao_social;
    public $cnpj;
    public $cod_cidade;

    public function __construct(){

    /*public function __construct( $cod_transportadora, $nome, $email, $telefone, $senha, $razao_social, $cnpj, $cod_cidade){

        $this->cod_transportadora = $cod_transportadora;
        $this->nome               = $nome;
        $this->email              = $email;
        $this->telefone           = $telefone;
        $this->senha              = $senha;
        $this->razao_social       = $razao_social;
        $this->cnpj               = $cnpj;
        $this->cod_cidade         = $cod_cidade;
    */

    }
}
