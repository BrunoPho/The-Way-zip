# Preenchendo formulários HTML automaticamente com AJAX

## Pequeno projeto para praticar JavaScript e AJAX 

Este projeto foi criado com base no tutorial criado por [Matheus Castiglioni](https://blog.alura.com.br/author/matheus-castiglioni/)
do blog Alura [Preenchendo formulário HTML automaticamente com AJAX](https://blog.alura.com.br/preenchendo-formulario-html-automaticamente-com-ajax/).

Foi utilizado o web service [viacep](https://viacep.com.br/).

Utilizei também o framework [Bootstrap 4](https://getbootstrap.com/).